"""Flask dashboard: separate DAAFUSION Detection and Smart Traffic views."""
from __future__ import annotations

import time
import random
from typing import TYPE_CHECKING

import cv2
import numpy as np
from flask import Flask, Response, jsonify, render_template, request

import config as cfg
import daafusion_core as core

if TYPE_CHECKING:
    from detection.lane_detector import LaneDetector
    from logic.signal_controller import SignalController

app = Flask(__name__)
detectors: dict[str, "LaneDetector"] = {}
controller: "SignalController | None" = None


def set_shared_state(det: dict, ctrl) -> None:
    global detectors, controller
    detectors = det
    controller = ctrl


def _generate_mjpeg(lane_name: str):
    while True:
        det = detectors.get(lane_name)
        if det is None:
            time.sleep(0.5)
            continue
        with det.lock:
            frame = det.latest_result.annotated_frame
        if frame is None:
            time.sleep(0.2)
            continue
        _, jpeg = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 86])
        yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpeg.tobytes() + b"\r\n"
        time.sleep(0.25)


@app.route("/feed/<lane_name>")
def video_feed(lane_name: str):
    if lane_name not in cfg.LANE_NAMES:
        return "Lane not found", 404
    return Response(_generate_mjpeg(lane_name), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/status")
def status():
    if controller is None:
        return jsonify({"error": "Controller not initialised"}), 503
    return jsonify(controller.get_status())


@app.route("/lane_samples")
def lane_samples():
    return jsonify({name: cfg.get_lane_sample(name) for name in cfg.LANE_NAMES})


@app.route("/scene_config")
def scene_config():
    return jsonify({
        "auto_rotate": cfg.get_auto_rotate(),
        "rotation_seconds": cfg.SAMPLE_ROTATION_SECONDS,
        "lanes": {name: cfg.get_lane_sample(name) for name in cfg.LANE_NAMES},
    })


@app.route("/set_sample/<lane_name>", methods=["POST"])
def set_sample(lane_name: str):
    if lane_name not in cfg.LANE_NAMES:
        return jsonify({"error": "Lane not found"}), 404
    sample_id = str((request.get_json(silent=True) or {}).get("sample_id", "")).strip().zfill(6)
    if not sample_id:
        return jsonify({"error": "sample_id is required"}), 400
    cfg.set_lane_sample(lane_name, sample_id)
    if controller is not None:
        controller.reset_lane_demand(lane_name)
    return jsonify({"success": True, "lane": lane_name, "sample_id": sample_id})


@app.route("/shuffle_samples", methods=["POST"])
def shuffle_samples():
    from detection.lane_detector import LaneDetector
    ids = LaneDetector._all_sample_ids
    if not ids:
        return jsonify({"error": "Dataset/model is not loaded yet"}), 503
    lanes = cfg.set_lane_samples_random(ids)
    if controller is not None:
        controller.reset_all_demand()
    return jsonify({"success": True, "lanes": lanes})


@app.route("/auto_rotate", methods=["POST"])
def auto_rotate():
    enabled = bool((request.get_json(silent=True) or {}).get("enabled", False))
    cfg.set_auto_rotate(enabled)
    return jsonify({"success": True, "auto_rotate": enabled, "interval_seconds": cfg.SAMPLE_ROTATION_SECONDS})


@app.route("/toggle_emergency/<lane_name>", methods=["POST"])
def toggle_emergency(lane_name: str):
    if lane_name not in cfg.LANE_NAMES:
        return jsonify({"error": "Lane not found"}), 404
    det = detectors.get(lane_name)
    if det is None:
        return jsonify({"error": "Detector not ready"}), 503
    active = bool((request.get_json(silent=True) or {}).get("active", True))
    det.set_manual_emergency(active)
    if controller is not None:
        controller.set_manual_emergency(lane_name, active)
    return jsonify({"success": True, "lane": lane_name, "emergency": active})


# ---------------------------------------------------------------------------
# Standalone detection tab
# ---------------------------------------------------------------------------
@app.route("/api/random_samples")
def random_samples():
    from detection.lane_detector import LaneDetector
    import random
    n = max(1, min(6, int(request.args.get("n", 6))))
    ids = LaneDetector._all_sample_ids
    if not ids:
        return jsonify({"error": "Dataset/model is not loaded yet"}), 503
    if len(ids) >= n:
        chosen = random.sample(ids, n)
    else:
        chosen = [random.choice(ids) for _ in range(n)]
    return jsonify({"samples": chosen})


@app.route("/api/detection/<sample_id>")
def detection(sample_id: str):
    from detection.lane_detector import LaneDetector
    from detection.visualizer import camera_uri, bev_uri

    sample_id = str(sample_id).strip().zfill(6)
    try:
        sample, pred = LaneDetector.infer_sample(sample_id)
        boxes = pred["boxes"]
        scores = pred["scores"]
        distances = [float((b[0] ** 2 + b[1] ** 2) ** 0.5) for b in boxes]

        # Build a collision-aware camera frame using the same visualizer as traffic mode.
        frame = LaneDetector._annotate_frame(sample, boxes, scores, distances, False)
        cam = camera_uri(frame)
        bev = bev_uri(sample, pred, show_gt=False)

        objects = []
        for b, score, dist in zip(boxes, scores, distances):
            objects.append({
                "class": "Car",
                "confidence": round(float(score) * 100, 1),
                "distance": round(float(dist), 2),
                "dimensions": [round(float(x), 2) for x in b[3:6]],
            })
        return jsonify({
            "success": True,
            "sample_id": sample_id,
            "camera": cam,
            "bev": bev,
            "objects": objects,
            "car_count": len(objects),
            "raw_count": int(pred.get("raw_count", len(objects))),
            "filtered_count": int(pred.get("filtered_count", len(objects))),
            "closest_distance": min(distances) if distances else None,
            "average_distance": sum(distances) / len(distances) if distances else None,
            "average_confidence": (sum(float(o["confidence"]) for o in objects) / len(objects)) if objects else None,
        })
    except FileNotFoundError:
        return jsonify({"error": f"KITTI sample {sample_id} was not found."}), 404
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/evaluate")
def evaluate():
    """Small on-demand detection evaluation using the same filtered pipeline."""
    from detection.lane_detector import LaneDetector
    try:
        n = max(1, min(12, int(request.args.get("n", 12))))
    except Exception:
        n = 12
    ids = [sid for sid in LaneDetector._all_sample_ids if (cfg.KITTI_TRAINING_ROOT)]
    if not ids:
        return jsonify({"error": "Dataset/model is not loaded yet"}), 503
    chosen = random.sample(ids, min(n, len(ids)))
    tp = fp = fn = 0
    used = 0
    try:
        for sid in chosen:
            sample, pred = LaneDetector.infer_sample(sid)
            pboxes = pred["boxes"]
            pclasses = pred["classes"]
            gt = sample.get("gt_boxes", np.zeros((0, 8), dtype=np.float32))
            gt = gt[gt[:, 7].astype(int) == 0] if len(gt) else gt
            matched = np.zeros(len(gt), dtype=bool)
            order = np.argsort(-pred["scores"]) if len(pboxes) else []
            for idx in order:
                pb = pboxes[idx]
                same = np.where(gt[:, 7].astype(int) == int(pclasses[idx]))[0] if len(gt) else np.array([], dtype=int)
                same = same[~matched[same]] if len(same) else same
                if len(same) == 0:
                    fp += 1
                    continue
                ious = core.bev_iou(pb, gt[same, :7])
                if len(ious) and float(ious.max()) >= 0.5:
                    best = int(np.argmax(ious))
                    matched[same[best]] = True
                    tp += 1
                else:
                    fp += 1
            fn += int((~matched).sum())
            used += 1
        precision = tp / max(tp + fp, 1)
        recall = tp / max(tp + fn, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-8)
        return jsonify({"samples": used, "tp": tp, "fp": fp, "fn": fn,
                        "precision": precision, "recall": recall, "f1": f1})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/model_info")
def model_info():
    from detection.lane_detector import LaneDetector
    return jsonify({
        "device": str(LaneDetector._device) if LaneDetector._device is not None else "not loaded",
        "samples": len(LaneDetector._all_sample_ids),
        "classes": ["Car"],
        "confidence_threshold": cfg.CONFIDENCE_THRESHOLD,
        "nms_iou": cfg.NMS_IOU_THRESHOLD,
        "max_display_distance_m": cfg.MAX_DISPLAY_DISTANCE_M,
        "dataset": cfg.KITTI_TRAINING_ROOT,
        "checkpoint": cfg.CHECKPOINT_PATH,
    })


@app.route("/api/settings", methods=["GET", "POST"])
def settings():
    if request.method == "GET":
        return jsonify({
            "confidence": cfg.CONFIDENCE_THRESHOLD,
            "nms_iou": cfg.NMS_IOU_THRESHOLD,
            "max_distance": cfg.MAX_DISPLAY_DISTANCE_M,
        })
    payload = request.get_json(silent=True) or {}
    try:
        if "confidence" in payload:
            cfg.CONFIDENCE_THRESHOLD = float(np.clip(float(payload["confidence"]), 0.85, 0.99))
        if "nms_iou" in payload:
            cfg.NMS_IOU_THRESHOLD = float(np.clip(float(payload["nms_iou"]), 0.10, 0.60))
    except Exception:
        return jsonify({"error": "Invalid detection settings"}), 400
    return jsonify({"success": True, "confidence": cfg.CONFIDENCE_THRESHOLD, "nms_iou": cfg.NMS_IOU_THRESHOLD})


@app.errorhandler(Exception)
def api_exception_handler(exc):
    # Keep API failures JSON so the browser never tries to parse an HTML
    # Flask error page as JSON ("Unexpected token <").
    path = request.path
    if path.startswith("/api/") or path.startswith("/shuffle_samples") or path.startswith("/toggle_emergency"):
        return jsonify({"error": str(exc) or "Internal server error"}), 500
    return str(exc) or "Internal server error", 500


@app.route("/")
def index():
    return render_template("index.html")
