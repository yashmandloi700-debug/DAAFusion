"""Reference evaluation numbers for the CAR-ONLY application view.

These are the previously recorded Phase-4 reference values; they are not
recomputed at application startup. The dashboard does not use them for signal
control. They are kept here only as a compact reference for presentations.
"""

REFERENCE_METRICS = {
    "class": "Car",
    "AP": 71.30,
    "validation_samples": 748,
}

DISPLAY_COLUMNS = ["Car"]

if __name__ == "__main__":
    print("DAAFUSION CAR-ONLY REFERENCE METRICS")
    print(f"Car AP: {REFERENCE_METRICS['AP']:.2f}")
    print(f"Validation samples: {REFERENCE_METRICS['validation_samples']}")
