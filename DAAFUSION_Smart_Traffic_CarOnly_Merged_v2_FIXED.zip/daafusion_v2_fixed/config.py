"""
Configuration for the merged STM + DAAFUSION project.

Everything that used to be a Streamlit sidebar field in daafusion_dashboard
(KITTI training folder, checkpoint path, confidence threshold, NMS IoU) is now
an environment variable here, since a Flask background-thread app has no
per-request sidebar.

Everything that used to be per-lane webp/jpg image paths in the original
Smart-Traffic-Management repo is now a per-lane KITTI *sample id*, because the
DAA model needs a paired LiDAR point cloud + calibration file behind every
image — it cannot run on an arbitrary uploaded photo the way the old YOLO
pipeline could.
"""

import os
import threading
import random
import time

# ── Lane configuration ──────────────────────────────────────────────────
LANE_NAMES: list[str] = ["north", "south", "east", "west"]

# ── DAAFUSION model / dataset (REQUIRED — fill these in) ───────────────
# Folder containing velodyne/, image_2/, calib/, label_2/ (KITTI "training" split)
KITTI_TRAINING_ROOT: str = os.getenv("KITTI_TRAINING_ROOT", r"D:\kitti\training")

# Path to your trained Phase-4 checkpoint (.pth)
CHECKPOINT_PATH: str = os.getenv("CHECKPOINT_PATH", r"C:\Users\SEVEN\Downloads\DAAFUSION_Streamlit_Dashboard_v2\best_model_phase4 (2).pth")

# ── Detection settings ───────────────────────────────────────────────────
CONFIDENCE_THRESHOLD: float = float(os.getenv("CONFIDENCE", "0.85"))
NMS_IOU_THRESHOLD: float = float(os.getenv("NMS_IOU", "0.30"))

# Post-decoding car-only quality gates. These are deliberately conservative for
# the demo because the Phase-4 checkpoint still has a 3-class output head.
MAX_DISPLAY_DISTANCE_M: float = float(os.getenv("MAX_DISPLAY_DISTANCE_M", "70"))
MIN_CAR_LENGTH_M: float = float(os.getenv("MIN_CAR_LENGTH_M", "2.2"))
MAX_CAR_LENGTH_M: float = float(os.getenv("MAX_CAR_LENGTH_M", "7.0"))
MIN_CAR_WIDTH_M: float = float(os.getenv("MIN_CAR_WIDTH_M", "1.3"))
MAX_CAR_WIDTH_M: float = float(os.getenv("MAX_CAR_WIDTH_M", "2.8"))
MIN_CAR_HEIGHT_M: float = float(os.getenv("MIN_CAR_HEIGHT_M", "1.2"))
MAX_CAR_HEIGHT_M: float = float(os.getenv("MAX_CAR_HEIGHT_M", "2.8"))
MIN_LIDAR_SUPPORT_NEAR: int = int(os.getenv("MIN_LIDAR_SUPPORT_NEAR", "10"))
MIN_LIDAR_SUPPORT_FAR: int = int(os.getenv("MIN_LIDAR_SUPPORT_FAR", "4"))
LIDAR_SUPPORT_STRICT_SCORE: float = float(os.getenv("LIDAR_SUPPORT_STRICT_SCORE", "0.985"))
MAX_DISPLAY_CARS: int = int(os.getenv("MAX_DISPLAY_CARS", "10"))
MIN_PROJECTED_BOX_AREA_PX: float = float(os.getenv("MIN_PROJECTED_BOX_AREA_PX", "80"))
MAX_PROJECTED_BOX_AREA_RATIO: float = float(os.getenv("MAX_PROJECTED_BOX_AREA_RATIO", "0.30"))
DISPLAY_2D_NMS_IOU: float = float(os.getenv("DISPLAY_2D_NMS_IOU", "0.45"))

# Inference on a full BEV+image fusion pass is much heavier than 2D YOLO —
# don't hammer it every second like the original repo did.
DETECTION_INTERVAL: float = float(os.getenv("DETECTION_INTERVAL", "4.0"))

# ── Signal timing (seconds) — unchanged from the original STM repo ─────
GREEN_DURATION: int = 20
YELLOW_DURATION: int = 4
EMERGENCY_DURATION: int = 15

# ── Scoring ───────────────────────────────────────────────────────────────
WAITING_WEIGHT: float = 0.5          # multiplier for waiting_cycles in score
SCORE_EMA_ALPHA: float = float(os.getenv("SCORE_EMA_ALPHA", "0.65"))
SWITCH_MARGIN: float = float(os.getenv("SWITCH_MARGIN", "0.20"))
DISTANCE_FLOOR_M: float = 1.0        # avoids divide-by-near-zero for very close objects

# ── Flask ─────────────────────────────────────────────────────────────────
FLASK_PORT: int = int(os.getenv("PORT", os.getenv("FLASK_PORT", "5000")))

# ── Per-lane KITTI sample id ────────────────────────────────────────────
# Pick any 4 sample ids that exist in your dataset's velodyne/ folder
# (e.g. "000010" -> velodyne/000010.bin, image_2/000010.png, calib/000010.txt).
# Changeable at runtime from the dashboard ("Set sample" per lane card).
_LANE_SAMPLE_LOCK = threading.RLock()
LANE_SAMPLE_IDS: dict[str, str] = {
    "north": os.getenv("LANE_NORTH_SAMPLE", "000010"),
    "south": os.getenv("LANE_SOUTH_SAMPLE", "000025"),
    "east":  os.getenv("LANE_EAST_SAMPLE", "000042"),
    "west":  os.getenv("LANE_WEST_SAMPLE", "000067"),
}

# Demo-mode scene selection. At startup the app can automatically choose four
# different KITTI samples so the traffic dashboard behaves like four camera
# feeds without requiring four real cameras.
RANDOMIZE_LANES_ON_START: bool = os.getenv("RANDOMIZE_LANES_ON_START", "1") != "0"
AUTO_ROTATE_SAMPLES: bool = os.getenv("AUTO_ROTATE_SAMPLES", "0") != "0"
SAMPLE_ROTATION_SECONDS: float = float(os.getenv("SAMPLE_ROTATION_SECONDS", "25"))

_SAMPLE_ROTATION_LOCK = threading.RLock()
_AUTO_ROTATE_ENABLED = AUTO_ROTATE_SAMPLES
_LAST_ROTATION = time.monotonic()


def get_lane_sample(lane_name: str) -> str:
    with _LANE_SAMPLE_LOCK:
        return LANE_SAMPLE_IDS.get(lane_name)


def set_lane_sample(lane_name: str, sample_id: str) -> None:
    with _LANE_SAMPLE_LOCK:
        LANE_SAMPLE_IDS[lane_name] = sample_id


def set_lane_samples_random(sample_ids: list[str], unique: bool = True) -> dict[str, str]:
    """Assign a fresh random set of four samples to the four lanes."""
    global _LAST_ROTATION
    ids = [str(x) for x in sample_ids if str(x)]
    if not ids:
        raise ValueError("No KITTI sample ids are available")
    with _LANE_SAMPLE_LOCK:
        if unique and len(ids) >= len(LANE_NAMES):
            chosen = random.sample(ids, len(LANE_NAMES))
        else:
            chosen = [random.choice(ids) for _ in LANE_NAMES]
        for lane, sid in zip(LANE_NAMES, chosen):
            LANE_SAMPLE_IDS[lane] = sid
        _LAST_ROTATION = time.monotonic()
        return dict(LANE_SAMPLE_IDS)


def get_auto_rotate() -> bool:
    with _SAMPLE_ROTATION_LOCK:
        return _AUTO_ROTATE_ENABLED


def set_auto_rotate(value: bool) -> None:
    global _AUTO_ROTATE_ENABLED, _LAST_ROTATION
    with _SAMPLE_ROTATION_LOCK:
        _AUTO_ROTATE_ENABLED = bool(value)
        _LAST_ROTATION = time.monotonic()


def should_rotate_samples() -> bool:
    with _SAMPLE_ROTATION_LOCK:
        return _AUTO_ROTATE_ENABLED and (time.monotonic() - _LAST_ROTATION >= SAMPLE_ROTATION_SECONDS)
