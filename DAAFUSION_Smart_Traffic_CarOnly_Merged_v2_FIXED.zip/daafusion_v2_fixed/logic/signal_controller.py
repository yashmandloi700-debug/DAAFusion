"""Stable distance-aware 4-way traffic signal controller."""
from __future__ import annotations

import threading
from time import monotonic
from dataclasses import dataclass
from typing import Optional

import config as cfg


@dataclass
class LaneState:
    name: str
    naive_count: int = 0
    weighted_score: float = 0.0
    smoothed_demand: float = 0.0
    score: float = 0.0
    avg_distance_m: Optional[float] = None
    closest_distance_m: Optional[float] = None
    signal: str = "RED"
    waiting_cycles: int = 0
    waiting_since: float = 0.0
    emergency_detected: bool = False
    error: Optional[str] = None


class SignalController:
    """Decision engine using filtered DAAFUSION car detections.

    Detection runs every few seconds, but the controller ticks every second.
    The demand signal is exponentially smoothed, so small inference changes do
    not cause the traffic lights to bounce between lanes.
    """

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.lanes: dict[str, LaneState] = {name: LaneState(name=name) for name in cfg.LANE_NAMES}
        self.active_green: str = cfg.LANE_NAMES[0]
        self.emergency_active = False
        self.emergency_lane: Optional[str] = None
        self._green_start = monotonic()
        self._yellow_active = False
        self._yellow_start = 0.0
        self._emergency_start = 0.0
        self._last_decision = "Initial lane: north"
        self._decision_count = 0

        now = monotonic()
        for ls in self.lanes.values():
            ls.waiting_since = now
        self.lanes[self.active_green].signal = "GREEN"
        self.lanes[self.active_green].waiting_since = 0.0

    def update(self, lane_results: dict) -> None:
        with self.lock:
            alpha = float(cfg.SCORE_EMA_ALPHA)
            for name in cfg.LANE_NAMES:
                ls = self.lanes[name]
                res = lane_results.get(name)
                if res is None:
                    continue
                ls.naive_count = int(res.naive_count)
                ls.weighted_score = float(res.weighted_score)
                ls.avg_distance_m = res.avg_distance_m
                ls.closest_distance_m = res.closest_distance_m
                ls.emergency_detected = bool(res.emergency_detected)
                ls.error = res.error
                if ls.error:
                    ls.smoothed_demand *= 0.85
                elif ls.smoothed_demand == 0.0:
                    ls.smoothed_demand = ls.weighted_score
                else:
                    ls.smoothed_demand = alpha * ls.weighted_score + (1.0 - alpha) * ls.smoothed_demand

            if self.emergency_active:
                if monotonic() - self._emergency_start >= cfg.EMERGENCY_DURATION:
                    lane = self.emergency_lane
                    self.emergency_active = False
                    self.emergency_lane = None
                    if lane in self.lanes:
                        self._set_green(lane)
                        self.active_green = lane
                    self._green_start = monotonic()
                    self._last_decision = "Emergency ended — automatic control resumed"
                else:
                    self._update_scores()
                    return

            self._update_scores()
            if self._yellow_active:
                if monotonic() - self._yellow_start >= cfg.YELLOW_DURATION:
                    self._finish_yellow()
                return

            if monotonic() - self._green_start >= cfg.GREEN_DURATION:
                self._begin_switch()

    def reset_lane_demand(self, lane_name: str) -> None:
        with self.lock:
            if lane_name in self.lanes:
                ls = self.lanes[lane_name]
                ls.naive_count = 0
                ls.weighted_score = 0.0
                ls.smoothed_demand = 0.0
                ls.score = 0.0
                ls.avg_distance_m = None
                ls.closest_distance_m = None

    def reset_all_demand(self) -> None:
        with self.lock:
            for ls in self.lanes.values():
                ls.naive_count = 0
                ls.weighted_score = 0.0
                ls.smoothed_demand = 0.0
                ls.score = 0.0
                ls.avg_distance_m = None
                ls.closest_distance_m = None

    def set_manual_emergency(self, lane_name: str, active: bool) -> None:
        with self.lock:
            if lane_name not in self.lanes:
                return
            if not active:
                if self.emergency_lane == lane_name:
                    self.emergency_active = False
                    self.emergency_lane = None
                    self._set_green(self.active_green)
                    self._green_start = monotonic()
                    self._last_decision = "Emergency cancelled — automatic control resumed"
                return
            self.emergency_active = True
            self.emergency_lane = lane_name
            self._emergency_start = monotonic()
            self._yellow_active = False
            self.active_green = lane_name
            self._set_green(lane_name)
            self._last_decision = f"Manual emergency override → {lane_name.upper()}"

    def get_status(self) -> dict:
        with self.lock:
            now = monotonic()
            lanes_status = {}
            for name in cfg.LANE_NAMES:
                ls = self.lanes[name]
                waiting_seconds = self._get_waiting_seconds(ls, now)
                lanes_status[name] = {
                    "sample_id": cfg.get_lane_sample(name),
                    "naive_count": ls.naive_count,
                    "weighted_score": round(ls.weighted_score, 3),
                    "smoothed_demand": round(ls.smoothed_demand, 3),
                    "avg_distance_m": round(ls.avg_distance_m, 1) if ls.avg_distance_m is not None else None,
                    "closest_distance_m": round(ls.closest_distance_m, 1) if ls.closest_distance_m is not None else None,
                    "score": round(ls.score, 3),
                    "signal": ls.signal,
                    "waiting": waiting_seconds,
                    "waiting_seconds": waiting_seconds,
                    "waiting_turns": ls.waiting_cycles,
                    "error": ls.error,
                    "count": ls.naive_count,
                }
            return {
                "lanes": lanes_status,
                "emergency_active": self.emergency_active,
                "emergency_lane": self.emergency_lane,
                "active_green": self.active_green,
                "phase": self._current_phase(),
                "phase_remaining_seconds": self._phase_remaining_seconds(now),
                "decision": self._last_decision,
                "decision_count": self._decision_count,
                "formula": "smoothed Σ(confidence / distance) + waiting fairness",
            }

    def _update_scores(self) -> None:
        for ls in self.lanes.values():
            # Waiting fairness is capped so it prevents starvation without
            # overwhelming a genuinely busy lane forever.
            fairness = min(ls.waiting_cycles, 8) * cfg.WAITING_WEIGHT
            ls.score = ls.smoothed_demand + fairness

    def _begin_switch(self) -> None:
        self.lanes[self.active_green].signal = "YELLOW"
        self._yellow_active = True
        self._yellow_start = monotonic()

    def _finish_yellow(self) -> None:
        self._yellow_active = False
        previous = self.active_green
        for ls in self.lanes.values():
            if ls.name != previous:
                ls.waiting_cycles += 1
        self.lanes[previous].waiting_cycles = 0
        self._update_scores()

        candidates = [ls for ls in self.lanes.values() if ls.name != previous]
        best = max(candidates, key=lambda ls: ls.score) if candidates else self.lanes[previous]
        self.active_green = best.name
        self._set_green(best.name)
        self._green_start = monotonic()
        self._decision_count += 1
        self._last_decision = (
            f"{best.name.upper()} selected: demand {best.smoothed_demand:.2f} "
            f"+ fairness {best.waiting_cycles * cfg.WAITING_WEIGHT:.2f}"
        )

    def _set_green(self, lane_name: str) -> None:
        now = monotonic()
        for ls in self.lanes.values():
            if ls.name == lane_name:
                ls.signal = "GREEN"
                ls.waiting_since = 0.0
            else:
                if ls.signal != "RED":
                    ls.waiting_since = now
                ls.signal = "RED"

    def _get_waiting_seconds(self, lane: LaneState, now: float) -> int:
        if lane.signal != "RED" or lane.waiting_since <= 0:
            return 0
        return max(0, int(now - lane.waiting_since))

    def _current_phase(self) -> str:
        if self.emergency_active:
            return "EMERGENCY"
        if self._yellow_active:
            return "YELLOW"
        return "GREEN"

    def _phase_remaining_seconds(self, now: float) -> int:
        if self.emergency_active:
            remaining = cfg.EMERGENCY_DURATION - (now - self._emergency_start)
        elif self._yellow_active:
            remaining = cfg.YELLOW_DURATION - (now - self._yellow_start)
        else:
            remaining = cfg.GREEN_DURATION - (now - self._green_start)
        return max(0, int(remaining))
