# DAAFUSION Smart Traffic Platform — Car Only v2

This version keeps the two project modes separate while sharing one DAAFUSION Phase-4 detector:

- **Detection:** specific KITTI sample or six random samples; camera 3D car cuboids, LiDAR BEV, distance, confidence, dimensions, reference metrics and an on-demand detection outcome matrix.
- **Traffic Management:** four random KITTI scenes act as North/South/East/West; the four feeds are fixed until Shuffle is pressed. Only the **final filtered Car detections** feed traffic demand and signal control.

## What changed in v2

### False-positive reduction
The application no longer treats every raw class-0 prediction as a visible car. A prediction must pass:

1. Car class filter
2. Confidence threshold (default **0.90**)
3. Reasonable 3D car dimensions
4. Reasonable distance (1.5–75 m)
5. LiDAR point-support check, adaptive for near/far cars
6. Valid camera projection and reasonable projected footprint
7. Existing oriented BEV NMS

The traffic controller receives exactly these final detections, so hidden/raw false positives cannot inflate the traffic score.

### Cleaner 3D visualization
- Cuboid edges are drawn from the same 3D box used by the BEV view.
- Camera cuboids are clipped at the camera near plane.
- Labels are limited to the strongest six accepted cars and use collision-aware placement.
- Only final detections are shown in the normal BEV; ground truth is hidden by default to avoid visual confusion.
- Full-screen viewer uses a proper two-pane object-fit layout and can be closed with Escape.

### Stable traffic control
Detection is still relatively expensive on CPU, but the signal controller now ticks every second using the latest result. Traffic demand is an **EMA-smoothed** version of:

`Σ(confidence / distance)`

plus a capped waiting-fairness bonus. A signal stays green for a fixed minimum phase, then changes through yellow. Small inference fluctuations therefore do not immediately change the lights.

Emergency override is separate and immediate: activating North/South/East/West gives that lane GREEN for the emergency duration, after which automatic control resumes.

## Paths used on the user's Windows setup

`config.py` defaults to:

```text
KITTI_TRAINING_ROOT = D:\kitti\training
CHECKPOINT_PATH = C:\Users\SEVEN\Downloads\DAAFUSION_Streamlit_Dashboard_v2\best_model_phase4 (2).pth
```

## Run

```powershell
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python main.py
```

Open:

```text
http://localhost:5000
```

## Detection tab

- Set confidence and NMS from the toolbar.
- `Run Sample` for a specific KITTI ID.
- `Run 6 Random Samples` for six different scenes.
- Click either image for the full-screen viewer.
- The table contains only final Car detections.
- The reference Phase-4 numbers are shown without being used by traffic control.
- `Compute on 12 random validation scenes` calculates TP/FP/FN using the current filtered Car-only pipeline and BEV IoU >= 0.5. A true-negative count is not meaningful for object detection.

## Traffic Management tab

- Four different KITTI samples are assigned to North/South/East/West at startup.
- `Shuffle 4 Scenes` chooses four new scenes.
- No emergency button is needed for normal operation.
- The active signal is selected when the current green phase ends.
- Demand is based on the same final detections visible in the feed.
- EMA smoothing and waiting fairness stop rapid signal oscillation.

### Normal signal basis

```text
object contribution = confidence / distance
lane demand = EMA(sum of object contributions)
priority = lane demand + waiting fairness
```

The lane with the highest priority among the other approaches receives GREEN at the end of the current green/yellow cycle.

## Important model note

The Phase-4 checkpoint still has a 3-output architecture for compatibility with the trained weights. The **application layer exposes only class 0 (Car)**. Pedestrian/Cyclist outputs are not displayed, scored, plotted or sent to traffic control.

The original standalone confusion-matrix counts were not present in this merged ZIP, so the dashboard calculates TP/FP/FN from the current Car-only pipeline instead of inventing counts. Instead, it provides an on-demand TP/FP/FN detection outcome matrix using the actual current pipeline.

## Structure

```text
DAAFUSION_Smart_Traffic_CarOnly_Merged_v2/
├── main.py
├── config.py
├── daafusion_core.py
├── requirements.txt
├── reference_metrics.py
├── detection/
│   ├── lane_detector.py
│   └── visualizer.py
├── logic/
│   └── signal_controller.py
└── dashboard/
    ├── app.py
    └── templates/
        └── index.html
```
