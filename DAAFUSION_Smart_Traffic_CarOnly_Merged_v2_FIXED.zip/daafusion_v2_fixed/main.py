"""
Smart Traffic Management + DAAFUSION — Entry Point.

Orchestrates:
1. Initialisation of per-lane DAAFUSION detectors (loads the checkpoint once).
2. A background detection loop (one thread per lane).
3. The centralized signal controller, driven by distance+quality-weighted score.
4. The Flask dashboard server.

Usage::

    python main.py
    # Then open http://localhost:5000

Before running, set these in config.py or as environment variables:
    KITTI_TRAINING_ROOT   -- folder containing velodyne/, image_2/, calib/, label_2/
    CHECKPOINT_PATH       -- your trained Phase-4 .pth checkpoint
"""

from __future__ import annotations

import sys
import os
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config as cfg
from detection.lane_detector import LaneDetector
from logic.signal_controller import SignalController
from dashboard.app import app, set_shared_state


def detection_loop(detector: LaneDetector, stop_event: threading.Event) -> None:
    while not stop_event.is_set():
        try:
            detector.detect()
        except Exception as exc:  # noqa: BLE001
            print(f"[{detector.lane_name}] detection error: {exc}")
        time.sleep(cfg.DETECTION_INTERVAL)


def control_loop(
    controller: SignalController,
    detectors: dict[str, LaneDetector],
    stop_event: threading.Event,
) -> None:
    while not stop_event.is_set():
        lane_results = {}
        for name, det in detectors.items():
            with det.lock:
                lane_results[name] = det.latest_result
        controller.update(lane_results)
        time.sleep(1.0)



def sample_rotation_loop(stop_event: threading.Event) -> None:
    """Optional demo mode: periodically assign four fresh KITTI scenes."""
    while not stop_event.is_set():
        if cfg.should_rotate_samples() and LaneDetector._all_sample_ids:
            try:
                cfg.set_lane_samples_random(LaneDetector._all_sample_ids)
                print(f"  ↻ Randomized four traffic scenes: {cfg.LANE_SAMPLE_IDS}")
            except Exception as exc:
                print(f"  Scene rotation error: {exc}")
        time.sleep(1.0)

def main() -> None:
    print("=" * 64)
    print("  Smart Traffic Management System + DAAFUSION 3D Detection")
    print("=" * 64)

    if not cfg.KITTI_TRAINING_ROOT or not cfg.CHECKPOINT_PATH:
        print(
            "\n  ⚠  KITTI_TRAINING_ROOT and/or CHECKPOINT_PATH are not set.\n"
            "     Edit config.py, or run with:\n"
            "       KITTI_TRAINING_ROOT=/path/to/training "
            "CHECKPOINT_PATH=/path/to/checkpoint.pth python main.py\n"
            "     The server will still start, but every lane will show an\n"
            "     error until these are set (no restart needed to fix them —\n"
            "     stop, export the variables, and rerun).\n"
        )

    detectors: dict[str, LaneDetector] = {}
    for name in cfg.LANE_NAMES:
        print(f"  ► Initialising detector for lane: {name} "
              f"(sample {cfg.get_lane_sample(name)})")
        detectors[name] = LaneDetector(name)
    print()

    controller = SignalController()
    set_shared_state(detectors, controller)

    stop_event = threading.Event()
    threads: list[threading.Thread] = []

    for name, det in detectors.items():
        t = threading.Thread(
            target=detection_loop, args=(det, stop_event),
            daemon=True, name=f"detect-{name}",
        )
        t.start()
        threads.append(t)
        print(f"  ✓ Detection thread started: {name}")

    sig_thread = threading.Thread(
        target=control_loop, args=(controller, detectors, stop_event),
        daemon=True, name="signal-controller",
    )
    sig_thread.start()
    print("  ✓ Signal controller thread started")

    rotate_thread = threading.Thread(
        target=sample_rotation_loop, args=(stop_event,),
        daemon=True, name="sample-rotation",
    )
    rotate_thread.start()
    print(f"  ✓ Random-scene demo: {'AUTO' if cfg.get_auto_rotate() else 'MANUAL'}")

    print(f"\n  Dashboard: http://localhost:{cfg.FLASK_PORT}\n")
    try:
        app.run(host="0.0.0.0", port=cfg.FLASK_PORT, debug=False,
                 threaded=True, use_reloader=False)
    except KeyboardInterrupt:
        print("\nShutting down...")
        stop_event.set()
        for t in threads:
            t.join(timeout=2)
        sig_thread.join(timeout=2)
        rotate_thread.join(timeout=2)
        print("Done.")


if __name__ == "__main__":
    main()
