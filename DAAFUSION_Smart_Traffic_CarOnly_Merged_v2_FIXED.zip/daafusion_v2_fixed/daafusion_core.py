"""
daafusion_core.py

Model architecture, KITTI I/O, BEV projection, decoding/NMS and evaluation
logic — ported 1:1 from the DAAFUSION Phase-4 training notebook so the
Streamlit dashboard runs real inference with the real checkpoint, not a mock.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as T
import torchvision.models as models
from pathlib import Path
from PIL import Image
from collections import defaultdict

# ------------------------------------------------------------------
# Config (identical to CFG in the notebook)
# ------------------------------------------------------------------
CFG = {
    'bev_x_range':   (0.0, 70.4),
    'bev_y_range':   (-40.0, 40.0),
    'bev_z_range':   (-3.0, 1.0),
    'bev_resolution': 0.2,
    'bev_channels':   5,

    'img_h': 384,
    'img_w': 1280,

    'backbone': 'resnet18',
    'feat_channels': 256,
    'num_heads': 4,
    'num_classes': 3,
    'anchor_sizes': [
        (3.9, 1.6, 1.56),
        (0.8, 0.6, 1.73),
        (1.76, 0.6, 1.73),
    ],
    'iou_threshold': 0.5,
    'val_split': 0.1,
    'seed': 42,
}
CFG['bev_h'] = int((CFG['bev_x_range'][1] - CFG['bev_x_range'][0]) / CFG['bev_resolution'])
CFG['bev_w'] = int((CFG['bev_y_range'][1] - CFG['bev_y_range'][0]) / CFG['bev_resolution'])

# The trained checkpoint keeps 3 output channels for weight compatibility.
# The application exposes ONLY class 0 (Car). Other output channels are never
# displayed, scored, plotted, or evaluated.
MODEL_NUM_CLASSES = 3
CAR_CLASS_ID = 0
CAR_NAME = "Car"
CLASS_COLORS = {CAR_CLASS_ID: "#22d3ee"}
DISPLAY_CLASS_IDS = (CAR_CLASS_ID,)
GROUND_OFFSET = -0.03
CAMERA_NEAR_Z = 0.10
CAR_DIM_RANGES = {
    "l": (2.2, 7.5),
    "w": (1.3, 3.0),
    "h": (1.2, 3.0),
}
MAX_DISPLAY_DISTANCE = 80.0


# ==================================================================
# KITTI I/O
# ==================================================================
def parse_calib(path):
    calib = {}
    with open(path, 'r') as f:
        for line in f:
            if ':' not in line:
                continue
            key, vals = line.strip().split(':', 1)
            calib[key.strip()] = np.array([float(x) for x in vals.strip().split()], dtype=np.float32)

    P2 = calib['P2'].reshape(3, 4)
    R0 = calib['R0_rect'].reshape(3, 3)
    Tr = calib['Tr_velo_to_cam'].reshape(3, 4)

    R0_4 = np.eye(4, dtype=np.float32)
    R0_4[:3, :3] = R0
    Tr_4 = np.eye(4, dtype=np.float32)
    Tr_4[:3, :] = Tr

    V2C = R0_4 @ Tr_4
    return dict(P2=P2, R0=R0, Tr=Tr, V2C=V2C)


def parse_labels(path):
    """Read only KITTI Car labels for the car-only application."""
    objects = []
    with open(path, "r") as f:
        for line in f:
            parts = line.strip().split()
            if not parts or parts[0].strip().lower() != "car":
                continue
            obj = {
                "type": "Car",
                "class_id": CAR_CLASS_ID,
                "truncated": float(parts[1]),
                "occluded": int(parts[2]),
                "alpha": float(parts[3]),
                "bbox": np.array(parts[4:8], dtype=np.float32),
                "dimensions": np.array(parts[8:11], dtype=np.float32),  # h, w, l
                "location": np.array(parts[11:14], dtype=np.float32),
                "rotation_y": float(parts[14]),
            }
            objects.append(obj)
    return objects


def cam_to_lidar(location, V2C):
    C2V = np.linalg.inv(V2C)
    pt = np.array([*location, 1.0], dtype=np.float32)
    return (C2V @ pt)[:3]


def get_lidar_boxes(labels, V2C):
    boxes = []
    for obj in labels:
        h, w, l = obj['dimensions']
        loc_cam = obj['location']
        rot_y = obj['rotation_y']

        loc_lidar = cam_to_lidar(loc_cam, V2C)
        loc_lidar[2] += h / 2.0

        yaw = -(rot_y + np.pi / 2)
        yaw = (yaw + np.pi) % (2 * np.pi) - np.pi

        boxes.append([loc_lidar[0], loc_lidar[1], loc_lidar[2], l, w, h, yaw, obj['class_id']])
    return np.array(boxes, dtype=np.float32) if boxes else np.zeros((0, 8), dtype=np.float32)


def load_point_cloud(bin_path):
    return np.fromfile(bin_path, dtype=np.float32).reshape(-1, 4)


def point_cloud_to_bev(pts, cfg):
    x_min, x_max = cfg['bev_x_range']
    y_min, y_max = cfg['bev_y_range']
    z_min, z_max = cfg['bev_z_range']
    res = cfg['bev_resolution']
    H, W = cfg['bev_h'], cfg['bev_w']

    mask = (
        (pts[:, 0] >= x_min) & (pts[:, 0] < x_max) &
        (pts[:, 1] >= y_min) & (pts[:, 1] < y_max) &
        (pts[:, 2] >= z_min) & (pts[:, 2] < z_max)
    )
    pts = pts[mask]
    if pts.shape[0] == 0:
        return np.zeros((5, H, W), dtype=np.float32)

    xi = np.clip(np.floor((pts[:, 0] - x_min) / res).astype(np.int32), 0, H - 1)
    yi = np.clip(np.floor((pts[:, 1] - y_min) / res).astype(np.int32), 0, W - 1)

    bev = np.zeros((5, H, W), dtype=np.float32)
    count = np.zeros((H, W), dtype=np.float32)
    sum_z = np.zeros((H, W), dtype=np.float32)
    sum_int = np.zeros((H, W), dtype=np.float32)

    np.maximum.at(bev[0], (xi, yi), pts[:, 2])
    np.add.at(sum_z, (xi, yi), pts[:, 2])
    np.add.at(count, (xi, yi), 1)
    np.maximum.at(bev[3], (xi, yi), pts[:, 3])
    np.add.at(sum_int, (xi, yi), pts[:, 3])

    occupied = count > 0
    bev[1][occupied] = sum_z[occupied] / count[occupied]
    bev[2] = np.log1p(count)
    bev[4][occupied] = sum_int[occupied] / count[occupied]

    z_range = z_max - z_min
    bev[0] = np.clip((bev[0] - z_min) / z_range, 0, 1)
    bev[1] = np.clip((bev[1] - z_min) / z_range, 0, 1)
    bev[2] = bev[2] / (bev[2].max() + 1e-6)

    return bev


IMG_MEAN = [0.485, 0.456, 0.406]
IMG_STD = [0.229, 0.224, 0.225]
_img_transform = T.Compose([
    T.Resize((CFG['img_h'], CFG['img_w'])),
    T.ToTensor(),
    T.Normalize(mean=IMG_MEAN, std=IMG_STD),
])


def load_sample(data_dir, sample_id):
    """Loads one KITTI sample: raw image (PIL), model tensors, calib, GT boxes, raw points."""
    data_dir = Path(data_dir)
    pts = load_point_cloud(data_dir / 'velodyne' / f'{sample_id}.bin')
    img_pil = Image.open(data_dir / 'image_2' / f'{sample_id}.png').convert('RGB')
    calib = parse_calib(data_dir / 'calib' / f'{sample_id}.txt')

    label_path = data_dir / 'label_2' / f'{sample_id}.txt'
    gt_boxes = np.zeros((0, 8), dtype=np.float32)
    if label_path.exists():
        labels = parse_labels(label_path)
        gt_boxes = get_lidar_boxes(labels, calib['V2C'])

    bev = point_cloud_to_bev(pts, CFG)
    img_tensor = _img_transform(img_pil)

    return {
        "sample_id": sample_id,
        "points": pts,
        "image": img_pil,
        "calib": calib,
        "gt_boxes": gt_boxes,
        "bev_tensor": torch.from_numpy(bev).float(),
        "img_tensor": img_tensor,
    }


def find_kitti_training_root(search_hint=None):
    candidates = []
    if search_hint:
        candidates.append(Path(search_hint))
    candidates += [
        Path("/kaggle/input/datasets/garymk/kitti-3d-object-detection-dataset/training"),
        Path("/kaggle/input/kitti-3d-object-detection-dataset/training"),
        Path("/content/dataset/training"),
    ]
    for p in candidates:
        if p and (p / "velodyne").is_dir() and (p / "image_2").is_dir() and (p / "calib").is_dir():
            return p

    search_roots = [Path("/kaggle/input"), Path("/content"), Path(".")]
    for root in search_roots:
        if not root.exists():
            continue
        for velodyne in root.rglob("velodyne"):
            p = velodyne.parent
            if (p / "image_2").is_dir() and (p / "calib").is_dir():
                return p
    return None


def list_sample_ids(data_dir):
    data_dir = Path(data_dir)
    return sorted([p.stem for p in (data_dir / 'velodyne').glob('*.bin')])


def train_val_split(all_ids, val_split=0.1, seed=42):
    import random
    rng = random.Random(seed)
    ids = list(all_ids)
    rng.shuffle(ids)
    n_val = max(1, int(len(ids) * val_split))
    return ids[n_val:], ids[:n_val]


# ==================================================================
# MODEL (Phase-4 architecture, identical to the notebook)
# ==================================================================
class BEVEncoder(nn.Module):
    def __init__(self, in_channels=5, out_channels=256):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, 64, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.Conv2d(64, 128, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(128), nn.ReLU(inplace=True),
            nn.Conv2d(128, 256, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
            nn.Conv2d(256, out_channels, 3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(out_channels), nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.encoder(x)


class ImageEncoder(nn.Module):
    def __init__(self, backbone_name='resnet18', out_channels=256, pretrained=False):
        super().__init__()
        backbone = getattr(models, backbone_name)(weights=None)
        self.stem = nn.Sequential(backbone.conv1, backbone.bn1, backbone.relu, backbone.maxpool)
        self.layer1 = backbone.layer1
        self.layer2 = backbone.layer2
        self.layer3 = backbone.layer3
        layer3_out = 256 if backbone_name in ('resnet18', 'resnet34') else 1024
        self.proj = nn.Sequential(
            nn.Conv2d(layer3_out, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels), nn.ReLU(inplace=True),
        )

    def forward(self, x):
        x = self.stem(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        return self.proj(x)


class CrossAttentionFusion(nn.Module):
    def __init__(self, channels=256, num_heads=4, dropout=0.1, pool_size=25):
        super().__init__()
        self.channels = channels
        self.num_heads = num_heads
        self.pool_size = pool_size
        self.q_proj = nn.Linear(channels, channels, bias=False)
        self.k_proj = nn.Linear(channels, channels, bias=False)
        self.v_proj = nn.Linear(channels, channels, bias=False)
        self.out_proj = nn.Linear(channels, channels, bias=False)
        self.dropout = nn.Dropout(dropout)
        self.norm1 = nn.LayerNorm(channels)
        self.norm2 = nn.LayerNorm(channels)
        self.ffn = nn.Sequential(
            nn.Linear(channels, channels * 2), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(channels * 2, channels), nn.Dropout(dropout),
        )

    def forward(self, bev_feat, img_feat):
        B, C, Hb, Wb = bev_feat.shape
        bev_pool = F.adaptive_avg_pool2d(bev_feat, self.pool_size)
        img_pool = F.adaptive_avg_pool2d(img_feat, self.pool_size)
        P2 = self.pool_size * self.pool_size

        q = bev_pool.flatten(2).transpose(1, 2)
        k = img_pool.flatten(2).transpose(1, 2)
        v = k

        q, k, v = self.q_proj(q), self.k_proj(k), self.v_proj(v)
        head_dim = C // self.num_heads

        def split_heads(t):
            return t.view(B, P2, self.num_heads, head_dim).transpose(1, 2)
        q, k, v = split_heads(q), split_heads(k), split_heads(v)

        scale = head_dim ** -0.5
        scores = torch.matmul(q, k.transpose(-2, -1)) * scale
        attn = self.dropout(F.softmax(scores, dim=-1))
        out = torch.matmul(attn, v)
        out = out.transpose(1, 2).contiguous().view(B, P2, C)
        out = self.out_proj(out)

        bev_q = bev_pool.flatten(2).transpose(1, 2)
        out = self.norm1(bev_q + out)
        out = self.norm2(out + self.ffn(out))

        out = out.transpose(1, 2).view(B, C, self.pool_size, self.pool_size)
        out = F.interpolate(out, size=(Hb, Wb), mode='bilinear', align_corners=False)
        out = out + bev_feat
        return out


class DetectionHead(nn.Module):
    def __init__(self, in_channels=256, num_classes=3):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Conv2d(in_channels, 256, 3, padding=1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, 3, padding=1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
        )
        self.cls_head = nn.Conv2d(256, num_classes, 1)
        self.reg_head = nn.Conv2d(256, 8, 1)

    def forward(self, x):
        feat = self.shared(x)
        return self.cls_head(feat), self.reg_head(feat)


class DistanceAdaptiveGate(nn.Module):
    def __init__(self, channels):
        super().__init__()
        hidden = max(channels // 4, 8)
        self.gate = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False), nn.BatchNorm2d(hidden), nn.ReLU(inplace=True),
            nn.Conv2d(hidden, 1, 1), nn.Sigmoid()
        )

    def forward(self, x):
        return x * (1.0 + self.gate(x))


class ImageQualityEstimator(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.quality_net = nn.Sequential(
            nn.Conv2d(channels, channels // 2, 1), nn.BatchNorm2d(channels // 2), nn.ReLU(inplace=True),
            nn.Conv2d(channels // 2, 1, 1), nn.Sigmoid()
        )

    def forward(self, img_feat):
        return self.quality_net(img_feat)


class MultiScaleBEVEnhancement(nn.Module):
    def __init__(self, channels):
        super().__init__()
        hidden = max(channels // 4, 8)
        self.local_branch = nn.Sequential(
            nn.Conv2d(channels, hidden, 3, padding=1, bias=False), nn.BatchNorm2d(hidden), nn.ReLU(inplace=True))
        self.medium_branch = nn.Sequential(
            nn.Conv2d(channels, hidden, 5, padding=2, bias=False), nn.BatchNorm2d(hidden), nn.ReLU(inplace=True))
        self.context_branch = nn.Sequential(
            nn.Conv2d(channels, hidden, 3, padding=2, dilation=2, bias=False), nn.BatchNorm2d(hidden), nn.ReLU(inplace=True))
        self.fusion = nn.Sequential(
            nn.Conv2d(hidden * 3, channels, 1, bias=False), nn.BatchNorm2d(channels), nn.ReLU(inplace=True))
        self.gate = nn.Sequential(
            nn.Conv2d(channels, hidden, 1), nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, 1), nn.Sigmoid())

    def forward(self, x):
        multi_scale = torch.cat([self.local_branch(x), self.medium_branch(x), self.context_branch(x)], dim=1)
        enhanced = self.fusion(multi_scale)
        gate = self.gate(enhanced)
        return x + enhanced * gate


class BEVFusionDetectorPhase4(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        C = cfg['feat_channels']
        self.bev_encoder = BEVEncoder(in_channels=cfg['bev_channels'], out_channels=C)
        self.distance_gate = DistanceAdaptiveGate(C)
        self.multiscale_bev = MultiScaleBEVEnhancement(C)
        self.img_encoder = ImageEncoder(backbone_name=cfg['backbone'], out_channels=C)
        self.image_quality = ImageQualityEstimator(C)
        self.cross_attn = CrossAttentionFusion(channels=C, num_heads=cfg['num_heads'])
        self.det_head = DetectionHead(in_channels=C, num_classes=cfg['num_classes'])

    def forward(self, bev, img):
        bev_feat = self.bev_encoder(bev)
        bev_feat = self.distance_gate(bev_feat)
        bev_feat = self.multiscale_bev(bev_feat)

        img_feat = self.img_encoder(img)
        img_feat = F.interpolate(img_feat, size=bev_feat.shape[2:], mode='bilinear', align_corners=False)
        quality_gate = self.image_quality(img_feat)
        img_feat = img_feat * quality_gate

        fused = self.cross_attn(bev_feat, img_feat)
        cls_pred, reg_pred = self.det_head(fused)
        return cls_pred, reg_pred


def load_model(checkpoint_path, device):
    model = BEVFusionDetectorPhase4(CFG).to(device)
    ckpt = torch.load(checkpoint_path, map_location=device, weights_only=False)
    state_dict = ckpt["model"] if isinstance(ckpt, dict) and "model" in ckpt else ckpt
    model.load_state_dict(state_dict)
    model.eval()
    return model


# ==================================================================
# Oriented BEV IoU + class-wise NMS + decoder (identical to notebook)
# ==================================================================
def _box_polygon(box):
    x, y = float(box[0]), float(box[1])
    l, w = max(float(box[3]), 1e-3), max(float(box[4]), 1e-3)
    yaw = float(box[6])
    local = np.array([[l/2, w/2], [l/2, -w/2], [-l/2, -w/2], [-l/2, w/2]], dtype=np.float64)
    c, s = np.cos(yaw), np.sin(yaw)
    R = np.array([[c, -s], [s, c]], dtype=np.float64)
    poly = local @ R.T
    poly[:, 0] += x
    poly[:, 1] += y
    if _signed_polygon_area(poly) < 0:
        poly = poly[::-1]
    return poly


def _polygon_area(poly):
    if len(poly) < 3:
        return 0.0
    x, y = poly[:, 0], poly[:, 1]
    return 0.5 * abs(np.sum(x * np.roll(y, -1) - y * np.roll(x, -1)))


def _signed_polygon_area(poly):
    if len(poly) < 3:
        return 0.0
    x, y = poly[:, 0], poly[:, 1]
    return 0.5 * np.sum(x * np.roll(y, -1) - y * np.roll(x, -1))


def _inside(p, a, b):
    return ((b[0]-a[0])*(p[1]-a[1]) - (b[1]-a[1])*(p[0]-a[0])) >= -1e-9


def _line_intersection(s, e, a, b):
    dc, dp = a - b, s - e
    denom = dc[0]*dp[1] - dc[1]*dp[0]
    if abs(denom) < 1e-12:
        return e.copy()
    n1 = a[0]*b[1] - a[1]*b[0]
    n2 = s[0]*e[1] - s[1]*e[0]
    x = (n1*dp[0] - n2*dc[0]) / denom
    y = (n1*dp[1] - n2*dc[1]) / denom
    return np.array([x, y], dtype=np.float64)


def _polygon_clip(subject, clip):
    output = [p.copy() for p in subject]
    for i in range(len(clip)):
        if not output:
            break
        a, b = clip[i], clip[(i+1) % len(clip)]
        input_list, output = output, []
        s = input_list[-1]
        for e in input_list:
            e_inside, s_inside = _inside(e, a, b), _inside(s, a, b)
            if e_inside:
                if not s_inside:
                    output.append(_line_intersection(s, e, a, b))
                output.append(e)
            elif s_inside:
                output.append(_line_intersection(s, e, a, b))
            s = e
    return np.asarray(output, dtype=np.float64)


def _oriented_iou_single(box_a, box_b):
    pa, pb = _box_polygon(box_a), _box_polygon(box_b)
    area_a, area_b = _polygon_area(pa), _polygon_area(pb)
    if area_a <= 0 or area_b <= 0:
        return 0.0
    inter = _polygon_area(_polygon_clip(pa, pb))
    return float(inter / (area_a + area_b - inter + 1e-8))


def bev_iou(box_ref, boxes_others):
    boxes_others = np.asarray(boxes_others)
    if boxes_others.size == 0:
        return np.zeros(0, dtype=np.float32)
    return np.asarray([_oriented_iou_single(box_ref, b) for b in boxes_others], dtype=np.float32)


def bev_nms(boxes, scores, classes, iou_thresh=0.3):
    boxes, scores, classes = np.asarray(boxes), np.asarray(scores), np.asarray(classes)
    if len(boxes) == 0:
        return boxes, scores, classes
    keep = []
    for cls in np.unique(classes):
        idx = np.where(classes == cls)[0]
        order = idx[np.argsort(-scores[idx])]
        while len(order) > 0:
            i = order[0]
            keep.append(i)
            if len(order) == 1:
                break
            ious = bev_iou(boxes[i], boxes[order[1:]])
            order = order[1:][ious < iou_thresh]
    keep = np.asarray(keep, dtype=np.int64)
    keep = keep[np.argsort(-scores[keep])]
    return boxes[keep], scores[keep], classes[keep]


@torch.no_grad()
def decode_predictions(cls_pred, reg_pred, cfg, score_thresh=0.5, nms_iou=0.3):
    B, C, H, W = cls_pred.shape
    x_min, _ = cfg["bev_x_range"]
    y_min, _ = cfg["bev_y_range"]
    stride = cfg["bev_resolution"] * 8

    row_idx = torch.arange(H, device=cls_pred.device)
    col_idx = torch.arange(W, device=cls_pred.device)
    grid_x = x_min + (row_idx.float() + 0.5) * stride
    grid_y = y_min + (col_idx.float() + 0.5) * stride
    gx, gy = torch.meshgrid(grid_x, grid_y, indexing="ij")

    scores_all = torch.sigmoid(cls_pred)
    results = []
    for b in range(B):
        cls_scores, cls_ids = scores_all[b].max(dim=0)
        keep_mask = cls_scores > score_thresh
        if keep_mask.sum() == 0:
            results.append({"boxes": np.zeros((0, 7), dtype=np.float32),
                             "scores": np.zeros(0, dtype=np.float32),
                             "classes": np.zeros(0, dtype=np.int64)})
            continue

        reg = reg_pred[b]
        xs = (gx + reg[0])[keep_mask].cpu().numpy()
        ys = (gy + reg[1])[keep_mask].cpu().numpy()
        zs = reg[2][keep_mask].cpu().numpy()
        ls = torch.exp(reg[3]).clamp(max=100)[keep_mask].cpu().numpy()
        ws = torch.exp(reg[4]).clamp(max=100)[keep_mask].cpu().numpy()
        hs = torch.exp(reg[5]).clamp(max=100)[keep_mask].cpu().numpy()
        yaw = torch.atan2(reg[6], reg[7])[keep_mask].cpu().numpy()

        boxes = np.stack([xs, ys, zs, ls, ws, hs, yaw], axis=1).astype(np.float32)
        scores = cls_scores[keep_mask].cpu().numpy().astype(np.float32)
        classes = cls_ids[keep_mask].cpu().numpy().astype(np.int64)

        boxes, scores, classes = bev_nms(boxes, scores, classes, iou_thresh=nms_iou)
        results.append({"boxes": boxes, "scores": scores, "classes": classes})
    return results


@torch.no_grad()
def run_inference(model, sample, device, score_thresh=0.5, nms_iou=0.3):
    """Run Phase-4 inference and expose only Car detections."""
    bev = sample["bev_tensor"].unsqueeze(0).to(device)
    img = sample["img_tensor"].unsqueeze(0).to(device)
    cls_pred, reg_pred = model(bev, img)
    result = decode_predictions(
        cls_pred, reg_pred, CFG,
        score_thresh=score_thresh,
        nms_iou=nms_iou
    )[0]

    if len(result["boxes"]) == 0:
        return result

    keep = result["classes"] == CAR_CLASS_ID
    result = {
        "boxes": result["boxes"][keep],
        "scores": result["scores"][keep],
        "classes": result["classes"][keep],
    }
    return result


def box_distance(box):
    """Ground distance sqrt(x^2 + y^2) in the LiDAR frame."""
    return float(np.sqrt(box[0] ** 2 + box[1] ** 2))


# ==================================================================
# 3D box -> image projection (for drawing on the camera view)
# ==================================================================
def lidar_box_corners(box):
    """Return grounded 3D box corners in the LiDAR frame.

    The model/GT box representation uses center-z. For visualization we
    explicitly construct the box from its ground plane so it does not float
    above the vehicle.
    """
    x, y, z, l, w, h, yaw = [float(v) for v in box[:7]]
    l = float(np.clip(abs(l), *CAR_DIM_RANGES["l"]))
    w = float(np.clip(abs(w), *CAR_DIM_RANGES["w"]))
    h = float(np.clip(abs(h), *CAR_DIM_RANGES["h"]))

    # Model boxes are represented by their centre. Construct the visual box
    # from the ground plane so the bottom of the box sits on the road/object.
    z_bottom = z - h / 2.0 + GROUND_OFFSET

    corners = np.array([
        [ l/2,  w/2, 0.0],
        [ l/2, -w/2, 0.0],
        [-l/2, -w/2, 0.0],
        [-l/2,  w/2, 0.0],
        [ l/2,  w/2, h],
        [ l/2, -w/2, h],
        [-l/2, -w/2, h],
        [-l/2,  w/2, h],
    ], dtype=np.float64)

    c, ss = np.cos(yaw), np.sin(yaw)
    R = np.array([[c, -ss, 0], [ss, c, 0], [0, 0, 1]], dtype=np.float64)
    corners = corners @ R.T
    corners += np.array([x, y, z_bottom], dtype=np.float64)
    return corners


def _clip_camera_edge(p1, p2, near_z=CAMERA_NEAR_Z):
    z1, z2 = float(p1[2]), float(p2[2])
    if z1 < near_z and z2 < near_z:
        return None
    if z1 >= near_z and z2 >= near_z:
        return p1, p2
    dz = z2 - z1
    if abs(dz) < 1e-12:
        return None
    t = (near_z - z1) / dz
    q = p1 + np.clip(t, 0.0, 1.0) * (p2 - p1)
    return (q, p2) if z1 < near_z else (p1, q)


def project_box_edges_to_image(box, V2C, P2):
    """Project visible 3D box edges, clipping edges at the camera near plane."""
    corners_lidar = lidar_box_corners(box)
    ones = np.ones((8, 1), dtype=np.float64)
    corners_h = np.hstack([corners_lidar, ones])
    corners_cam = (V2C @ corners_h.T).T

    segments = []
    for a, b in BOX_EDGES:
        clipped = _clip_camera_edge(corners_cam[a, :3], corners_cam[b, :3])
        if clipped is None:
            continue
        p1, p2 = clipped
        pts = np.vstack([p1, p2])
        pts_h = np.hstack([pts, np.ones((2, 1), dtype=np.float64)])
        uvw = (P2 @ pts_h.T).T
        if np.any(np.abs(uvw[:, 2]) < 1e-8):
            continue
        uv = uvw[:, :2] / uvw[:, 2:3]
        if np.isfinite(uv).all() and np.max(np.abs(uv)) < 20000:
            segments.append(uv)
    return segments


def project_box_to_image(box, V2C, P2):
    """Compatibility helper returning all 8 projected corners when valid."""
    corners_lidar = lidar_box_corners(box)
    ones = np.ones((8, 1), dtype=np.float64)
    corners_h = np.hstack([corners_lidar, ones])
    corners_cam = (V2C @ corners_h.T).T
    if np.any(corners_cam[:, 2] <= CAMERA_NEAR_Z):
        return None
    uvw = (P2 @ corners_cam[:, :4].T).T
    if np.any(np.abs(uvw[:, 2]) < 1e-8):
        return None
    uv = uvw[:, :2] / uvw[:, 2:3]
    if not np.isfinite(uv).all() or np.max(np.abs(uv)) > 20000:
        return None
    return uv


@torch.no_grad()
def evaluate_subset(model, data_dir, sample_ids, device, score_thresh=0.1, nms_iou=0.3, iou_thresh=0.5):
    """Lightweight precision/recall/F1 evaluator over an arbitrary list of sample ids
    (same TP/FP matching logic as the notebook's `evaluate`, without a DataLoader)."""
    total_tp = total_fp = total_gt = 0
    per_class_counts = {CAR_CLASS_ID: {"tp": 0, "fp": 0, "gt": 0}}

    for sid in sample_ids:
        sample = load_sample(data_dir, sid)
        pred = run_inference(model, sample, device, score_thresh=score_thresh, nms_iou=nms_iou)
        gt_np = sample["gt_boxes"]
        if len(gt_np):
            gt_np = gt_np[np.isin(gt_np[:, 7].astype(int), DISPLAY_CLASS_IDS)]

        for c in DISPLAY_CLASS_IDS:
            n_cls = int((gt_np[:, 7] == c).sum()) if len(gt_np) else 0
            per_class_counts[c]["gt"] += n_cls
            total_gt += n_cls

        if len(pred["boxes"]) == 0:
            continue

        order = np.argsort(-pred["scores"])
        p_boxes = pred["boxes"][order]
        p_classes = pred["classes"][order]
        matched = np.zeros(len(gt_np), dtype=bool)

        for pb, pc in zip(p_boxes, p_classes):
            gt_same = np.where(gt_np[:, 7] == pc)[0] if len(gt_np) else np.array([], dtype=int)
            gt_same = gt_same[~matched[gt_same]]

            if len(gt_same) == 0:
                per_class_counts[int(pc)]["fp"] += 1
                total_fp += 1
                continue

            ious = bev_iou(pb, gt_np[gt_same])
            best_local = int(np.argmax(ious))
            if ious[best_local] >= iou_thresh:
                matched[gt_same[best_local]] = True
                per_class_counts[int(pc)]["tp"] += 1
                total_tp += 1
            else:
                per_class_counts[int(pc)]["fp"] += 1
                total_fp += 1

    per_class = {}
    for c in DISPLAY_CLASS_IDS:
        name = CAR_NAME
        tp, fp, gt = per_class_counts[c]["tp"], per_class_counts[c]["fp"], per_class_counts[c]["gt"]
        precision = tp / max(tp + fp, 1)
        recall = tp / max(gt, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-8)
        per_class[name] = {"precision": round(precision * 100, 2), "recall": round(recall * 100, 2),
                            "f1": round(f1 * 100, 2), "gt": gt, "tp": tp, "fp": fp}

    precision = total_tp / max(total_tp + total_fp, 1)
    recall = total_tp / max(total_gt, 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-8)

    return {"precision": precision, "recall": recall, "f1": f1, "per_class": per_class,
            "total_gt": total_gt, "total_tp": total_tp, "total_fp": total_fp}


# Proper cuboid topology: four edges on the ground rectangle, four on the
# roof rectangle, and four vertical edges. This avoids diagonal/crossed lines.
BOX_EDGES = [
    (0, 1), (1, 2), (2, 3), (3, 0),
    (4, 5), (5, 6), (6, 7), (7, 4),
    (0, 4), (1, 5), (2, 6), (3, 7),
]
