"""Clean, car-only camera/BEV visualization helpers."""
from __future__ import annotations

import io
import base64
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

import cv2
import daafusion_core as core


def _data_uri(raw: bytes) -> str:
    return "data:image/png;base64," + base64.b64encode(raw).decode("ascii")


def camera_uri(annotated_bgr: np.ndarray) -> str:
    ok, enc = cv2.imencode(".jpg", annotated_bgr, [cv2.IMWRITE_JPEG_QUALITY, 92])
    if not ok:
        raise RuntimeError("Could not encode camera visualization")
    return "data:image/jpeg;base64," + base64.b64encode(enc.tobytes()).decode("ascii")


def bev_uri(sample, pred, show_gt: bool = False) -> str:
    pts = sample["points"]
    fig, ax = plt.subplots(figsize=(11, 7), dpi=130)
    fig.patch.set_facecolor("#071522")
    ax.set_facecolor("#071522")

    if len(pts) > 50000:
        step = max(1, len(pts) // 50000)
        pts = pts[::step]
    ax.scatter(pts[:, 1], pts[:, 0], s=0.45, alpha=0.28, linewidths=0, c="#23d7c7")

    # Ground truth is intentionally hidden in normal demo mode so the user sees
    # only final model detections. It can still be enabled by an API caller.
    if show_gt:
        gt = sample.get("gt_boxes", np.zeros((0, 8), dtype=np.float32))
        for b in gt:
            if int(b[7]) != core.CAR_CLASS_ID:
                continue
            corners = core.lidar_box_corners(b[:7])
            poly = np.column_stack([corners[:4, 1], corners[:4, 0]])
            ax.add_patch(Polygon(poly, closed=True, fill=False, linewidth=1.2,
                                  linestyle="--", edgecolor="#dce6ef", alpha=0.55))

    for b, score in zip(pred["boxes"], pred["scores"]):
        corners = core.lidar_box_corners(b)
        poly = np.column_stack([corners[:4, 1], corners[:4, 0]])
        ax.add_patch(Polygon(poly, closed=True, fill=False, linewidth=2.2,
                              edgecolor="#22d3ee"))
        # Keep BEV clean: the detailed confidence/distance values are shown
        # in the detection table and camera view, not piled on top of boxes.

    ax.scatter([0], [0], marker="^", s=75, c="#ffffff", edgecolors="#22d3ee", linewidths=1.5, zorder=5)
    ax.text(0, 2.0, "LiDAR", color="#ffffff", fontsize=8, ha="center")
    ax.set_xlim(-40, 40)
    ax.set_ylim(0, 70.4)
    ax.set_xlabel("← left · lateral (m) · right →", color="#9fb0c4")
    ax.set_ylabel("forward distance (m)", color="#9fb0c4")
    ax.set_title("DAAFUSION — Car-only LiDAR BEV", color="#e9f4ff", fontsize=14, fontweight="bold")
    ax.grid(alpha=0.12, color="#b9c7d8")
    ax.tick_params(colors="#9fb0c4")
    for spine in ax.spines.values():
        spine.set_color("#284158")
    fig.tight_layout(pad=1.1)

    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)
    return _data_uri(buf.getvalue())
