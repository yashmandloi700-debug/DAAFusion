"""Shared car-only DAAFUSION detector with conservative demo-time filtering."""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Optional

import cv2
import numpy as np
import torch

import config as cfg
import daafusion_core as core


@dataclass
class DetectionResult:
    lane_name: str
    sample_id: str = ""
    naive_count: int = 0
    weighted_score: float = 0.0
    avg_distance_m: Optional[float] = None
    closest_distance_m: Optional[float] = None
    class_names: list[str] = field(default_factory=list)
    distances_m: list[float] = field(default_factory=list)
    confidences: list[float] = field(default_factory=list)
    boxes: np.ndarray = field(default_factory=lambda: np.zeros((0, 7), dtype=np.float32))
    scores: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.float32))
    classes: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.int64))
    emergency_detected: bool = False
    annotated_frame: Optional[np.ndarray] = None
    error: Optional[str] = None
    raw_count: int = 0
    filtered_count: int = 0

    @property
    def vehicle_count(self) -> int:
        return self.naive_count


class LaneDetector:
    _model = None
    _device = None
    _all_sample_ids: list[str] = []
    _init_lock = threading.Lock()
    _inference_lock = threading.Lock()
    _init_error: Optional[str] = None

    def __init__(self, lane_name: str) -> None:
        self.lane_name = lane_name
        self.lock = threading.Lock()
        self.latest_result = DetectionResult(lane_name=lane_name)
        self._manual_emergency = False
        self._ensure_model_loaded()

    @classmethod
    def _ensure_model_loaded(cls) -> None:
        if cls._model is not None or cls._init_error is not None:
            return
        with cls._init_lock:
            if cls._model is not None or cls._init_error is not None:
                return
            if not cfg.KITTI_TRAINING_ROOT or not cfg.CHECKPOINT_PATH:
                cls._init_error = "Dataset/checkpoint path is not configured. Edit config.py."
                return
            try:
                cls._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
                cls._model = core.load_model(cfg.CHECKPOINT_PATH, cls._device)
                cls._all_sample_ids = core.list_sample_ids(cfg.KITTI_TRAINING_ROOT)
                if len(cls._all_sample_ids) < len(cfg.LANE_NAMES):
                    cls._init_error = "The KITTI training folder contains fewer than 4 samples."
                    cls._model = None
                    return
                if cfg.RANDOMIZE_LANES_ON_START:
                    cfg.set_lane_samples_random(cls._all_sample_ids)
            except Exception as exc:
                cls._init_error = f"Failed to load DAAFUSION model/dataset: {exc}"

    @classmethod
    def infer_sample(cls, sample_id: str):
        """Run shared inference and return only quality-filtered Car detections."""
        cls._ensure_model_loaded()
        if cls._init_error:
            raise RuntimeError(cls._init_error)
        sample = core.load_sample(cfg.KITTI_TRAINING_ROOT, sample_id)
        with cls._inference_lock:
            pred = core.run_inference(
                cls._model, sample, cls._device,
                score_thresh=cfg.CONFIDENCE_THRESHOLD,
                nms_iou=cfg.NMS_IOU_THRESHOLD,
            )
        raw_count = len(pred["boxes"])
        pred = cls._quality_filter(sample, pred)
        pred["raw_count"] = raw_count
        pred["filtered_count"] = len(pred["boxes"])
        return sample, pred

    @staticmethod
    def _lidar_support(points: np.ndarray, box: np.ndarray) -> int:
        """Count LiDAR returns inside a slightly expanded oriented 3D box."""
        if points.size == 0:
            return 0
        x, y, z, l, w, h, yaw = [float(v) for v in box[:7]]
        l, w, h = abs(l), abs(w), abs(h)
        # A modest expansion avoids rejecting true cars because the predicted
        # center is a little off, while still rejecting floating false boxes.
        dl, dw, dh = l * 0.18, w * 0.22, h * 0.20
        dx = points[:, 0] - x
        dy = points[:, 1] - y
        c, s = np.cos(yaw), np.sin(yaw)
        local_x = c * dx + s * dy
        local_y = -s * dx + c * dy
        z_bottom = z - h / 2.0 - dh
        z_top = z + h / 2.0 + dh
        mask = (
            (np.abs(local_x) <= l / 2.0 + dl) &
            (np.abs(local_y) <= w / 2.0 + dw) &
            (points[:, 2] >= z_bottom) &
            (points[:, 2] <= z_top)
        )
        return int(mask.sum())

    @staticmethod
    def _refine_box_xy(points: np.ndarray, box: np.ndarray) -> np.ndarray:
        """Small LiDAR-supported centre refinement for cleaner 3D placement."""
        if points.size == 0:
            return box
        b = np.asarray(box, dtype=np.float32).copy()
        x, y, z, l, w, h, yaw = [float(v) for v in b[:7]]
        dx = points[:, 0] - x
        dy = points[:, 1] - y
        c, ss = np.cos(yaw), np.sin(yaw)
        local_x = c * dx + ss * dy
        local_y = -ss * dx + c * dy
        mask = (
            (np.abs(local_x) <= abs(l) * 0.62) &
            (np.abs(local_y) <= abs(w) * 0.68) &
            (points[:, 2] >= z - abs(h) * 0.75) &
            (points[:, 2] <= z + abs(h) * 0.75)
        )
        support = points[mask]
        if len(support) < 6:
            return b
        # Median is robust to a few returns from adjacent surfaces.
        target_x = float(np.median(support[:, 0]))
        target_y = float(np.median(support[:, 1]))
        b[0] = 0.70 * x + 0.30 * target_x
        b[1] = 0.70 * y + 0.30 * target_y
        return b

    @classmethod
    def _quality_filter(cls, sample, pred):
        """Conservative Car-only post-processing for presentation and traffic control.

        The Phase-4 network still has a 3-class head, but this application only
        accepts class 0 (Car).  A prediction must also have sensible 3D
        dimensions, LiDAR support and a valid camera projection.  A second
        camera-space NMS removes duplicate cuboids that can survive BEV NMS
        when their projections overlap.
        """
        boxes = np.asarray(pred["boxes"], dtype=np.float32).reshape(-1, 7)
        scores = np.asarray(pred["scores"], dtype=np.float32).reshape(-1)
        classes = np.asarray(pred["classes"], dtype=np.int64).reshape(-1)

        if len(boxes) == 0:
            return {"boxes": boxes, "scores": scores, "classes": classes}

        # Strictly Car.
        keep = classes == core.CAR_CLASS_ID
        boxes, scores, classes = boxes[keep], scores[keep], classes[keep]

        points = np.asarray(sample["points"], dtype=np.float32)
        if len(points) > 80000:
            points = points[::max(1, len(points) // 80000)]

        candidates = []
        image = np.asarray(sample["image"])
        ih, iw = image.shape[:2]
        P2, V2C = sample["calib"]["P2"], sample["calib"]["V2C"]

        for box, score, cls_id in zip(boxes, scores, classes):
            score = float(score)
            if not np.isfinite(box).all() or not np.isfinite(score):
                continue
            if score < cfg.CONFIDENCE_THRESHOLD:
                continue

            x, y, z, l, w, h, yaw = [float(v) for v in box]
            dist = float(np.hypot(x, y))
            dims_ok = (
                cfg.MIN_CAR_LENGTH_M <= abs(l) <= cfg.MAX_CAR_LENGTH_M and
                cfg.MIN_CAR_WIDTH_M <= abs(w) <= cfg.MAX_CAR_WIDTH_M and
                cfg.MIN_CAR_HEIGHT_M <= abs(h) <= cfg.MAX_CAR_HEIGHT_M
            )
            if not dims_ok or not (1.5 <= dist <= cfg.MAX_DISPLAY_DISTANCE_M):
                continue

            # Every displayed prediction must have actual LiDAR support.
            support = cls._lidar_support(points, box)
            min_support = cfg.MIN_LIDAR_SUPPORT_NEAR if dist <= 40.0 else cfg.MIN_LIDAR_SUPPORT_FAR
            if support < min_support:
                continue

            try:
                segments = core.project_box_edges_to_image(box, V2C, P2)
                if len(segments) < 4:
                    continue
                uv = np.vstack(segments)
                if not np.isfinite(uv).all():
                    continue
                x1, y1 = float(uv[:, 0].min()), float(uv[:, 1].min())
                x2, y2 = float(uv[:, 0].max()), float(uv[:, 1].max())
                ix1, iy1 = max(0.0, x1), max(0.0, y1)
                ix2, iy2 = min(float(iw - 1), x2), min(float(ih - 1), y2)
                pw, ph = ix2 - ix1, iy2 - iy1
                area = pw * ph
                if pw < 8 or ph < 8 or area < cfg.MIN_PROJECTED_BOX_AREA_PX:
                    continue
                if area > iw * ih * cfg.MAX_PROJECTED_BOX_AREA_RATIO:
                    continue
                aspect = pw / max(ph, 1.0)
                if not 0.25 <= aspect <= 5.5:
                    continue
            except Exception:
                continue

            refined_box = cls._refine_box_xy(points, box)
            candidates.append({
                "box": refined_box, "score": score, "class": int(cls_id),
                "bbox2d": (ix1, iy1, ix2, iy2), "support": support, "dist": dist
            })

        if not candidates:
            return {
                "boxes": np.zeros((0, 7), dtype=np.float32),
                "scores": np.zeros(0, dtype=np.float32),
                "classes": np.zeros(0, dtype=np.int64),
            }

        # Strongest predictions first. Suppress camera-space duplicates.
        candidates.sort(key=lambda q: q["score"], reverse=True)

        def iou2d(a, b):
            ax1, ay1, ax2, ay2 = a
            bx1, by1, bx2, by2 = b
            ix1, iy1 = max(ax1, bx1), max(ay1, by1)
            ix2, iy2 = min(ax2, bx2), min(ay2, by2)
            inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
            aa = max(0.0, ax2-ax1) * max(0.0, ay2-ay1)
            ab = max(0.0, bx2-bx1) * max(0.0, by2-by1)
            return inter / max(aa + ab - inter, 1e-6)

        selected = []
        for cand in candidates:
            if any(iou2d(cand["bbox2d"], prev["bbox2d"]) >= cfg.DISPLAY_2D_NMS_IOU
                   for prev in selected):
                continue
            selected.append(cand)
            if len(selected) >= cfg.MAX_DISPLAY_CARS:
                break

        selected.sort(key=lambda q: q["score"], reverse=True)
        return {
            "boxes": np.asarray([q["box"] for q in selected], dtype=np.float32),
            "scores": np.asarray([q["score"] for q in selected], dtype=np.float32),
            "classes": np.asarray([q["class"] for q in selected], dtype=np.int64),
        }

    def set_manual_emergency(self, value: bool) -> None:
        with self.lock:
            self._manual_emergency = bool(value)

    def detect(self) -> DetectionResult:
        sample_id = cfg.get_lane_sample(self.lane_name)
        if self._init_error:
            result = DetectionResult(self.lane_name, sample_id=sample_id, error=self._init_error)
            with self.lock:
                self.latest_result = result
            return result

        try:
            sample, pred = self.infer_sample(sample_id)
            boxes = pred["boxes"]
            scores = pred["scores"]
            classes = pred["classes"]
            raw_count = int(pred.get("raw_count", len(boxes)))
        except FileNotFoundError:
            result = DetectionResult(self.lane_name, sample_id=sample_id,
                                     error=f"Sample {sample_id} is missing image_2/velodyne/calib/label_2 files.")
            with self.lock:
                self.latest_result = result
            return result
        except Exception as exc:
            result = DetectionResult(self.lane_name, sample_id=sample_id, error=str(exc))
            with self.lock:
                self.latest_result = result
            return result

        distances = [core.box_distance(b) for b in boxes]
        naive_count = len(boxes)
        weighted_score = float(sum(float(s) / max(float(d), cfg.DISTANCE_FLOOR_M)
                                   for s, d in zip(scores, distances)))
        avg_distance = float(np.mean(distances)) if distances else None
        closest_distance = float(np.min(distances)) if distances else None
        class_names = [core.CAR_NAME] * len(boxes)

        with self.lock:
            emergency = self._manual_emergency

        annotated = self._annotate_frame(sample, boxes, scores, distances, emergency)
        result = DetectionResult(
            lane_name=self.lane_name,
            sample_id=sample_id,
            naive_count=naive_count,
            weighted_score=weighted_score,
            avg_distance_m=avg_distance,
            closest_distance_m=closest_distance,
            class_names=class_names,
            distances_m=[float(d) for d in distances],
            confidences=[float(s) for s in scores],
            boxes=boxes,
            scores=scores,
            classes=classes,
            emergency_detected=emergency,
            annotated_frame=annotated,
            raw_count=raw_count,
            filtered_count=naive_count,
        )
        with self.lock:
            self.latest_result = result
        return result

    @staticmethod
    def _annotate_frame(sample, boxes, scores, distances, emergency) -> np.ndarray:
        img = cv2.cvtColor(np.array(sample["image"]), cv2.COLOR_RGB2BGR).copy()
        V2C, P2 = sample["calib"]["V2C"], sample["calib"]["P2"]
        h, w = img.shape[:2]

        projected = []
        for box, score, dist in zip(boxes, scores, distances):
            segments = core.project_box_edges_to_image(box, V2C, P2)
            if len(segments) < 2:
                continue
            all_uv = np.vstack(segments)
            x1 = max(0, min(w - 1, int(np.floor(all_uv[:, 0].min()))))
            y1 = max(0, min(h - 1, int(np.floor(all_uv[:, 1].min()))))
            x2 = max(0, min(w - 1, int(np.ceil(all_uv[:, 0].max()))))
            y2 = max(0, min(h - 1, int(np.ceil(all_uv[:, 1].max()))))
            if x2 <= x1 or y2 <= y1:
                continue
            projected.append((segments, x1, y1, x2, y2, float(score), float(dist)))

        # Draw cuboids first; use a single consistent Car color.
        for segments, *_ in projected:
            for seg in segments:
                p1 = tuple(np.round(seg[0]).astype(int))
                p2 = tuple(np.round(seg[1]).astype(int))
                cv2.line(img, p1, p2, (34, 211, 238), 2, cv2.LINE_AA)

        # Labels are anchored to their own projected box and placed in a lane-like
        # stack. This prevents the dense label collisions visible in the old UI.
        placed = []
        # Labels are intentionally limited to the six strongest detections.
        # All accepted cuboids remain visible, but text never blankets the scene.
        for label_idx, (_, x1, y1, x2, y2, score, dist) in enumerate(
            sorted(projected, key=lambda z: z[5], reverse=True)
        ):
            if label_idx >= 6:
                break
            text = f"Car {score * 100:.0f}% · {dist:.1f}m"
            scale = 0.48 if dist > 45 else 0.55
            thickness = 1 if dist > 45 else 2
            (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, thickness)
            lx = max(5, min(x1, w - tw - 10))
            candidates = [max(th + 6, y1 - 6), y2 + th + 8, y1 + th + 8]
            ly = candidates[0]
            for candidate in candidates:
                candidate = min(h - 5, max(th + 5, candidate))
                rect = (lx - 4, candidate - th - 5, lx + tw + 5, candidate + 4)
                if not any(not (rect[2] < r[0] or rect[0] > r[2] or rect[3] < r[1] or rect[1] > r[3]) for r in placed):
                    ly = candidate
                    break
            rect = (lx - 4, ly - th - 5, lx + tw + 5, ly + 4)
            placed.append(rect)
            cv2.rectangle(img, (rect[0], rect[1]), (rect[2], rect[3]), (3, 13, 22), -1)
            cv2.putText(img, text, (lx, ly), cv2.FONT_HERSHEY_SIMPLEX, scale,
                        (34, 211, 238), thickness, cv2.LINE_AA)

        overlay = f"KITTI {sample['sample_id']}  •  {len(projected)} CARS"
        (tw, th), _ = cv2.getTextSize(overlay, cv2.FONT_HERSHEY_SIMPLEX, 0.65, 2)
        cv2.rectangle(img, (0, 0), (tw + 20, th + 20), (3, 13, 22), -1)
        cv2.putText(img, overlay, (10, th + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.65,
                    (245, 250, 255), 2, cv2.LINE_AA)

        if emergency:
            cv2.rectangle(img, (2, 2), (w - 3, h - 3), (40, 40, 230), 4)
            cv2.putText(img, "EMERGENCY OVERRIDE", (20, 42), cv2.FONT_HERSHEY_SIMPLEX,
                        0.85, (40, 40, 230), 2, cv2.LINE_AA)
        return img
