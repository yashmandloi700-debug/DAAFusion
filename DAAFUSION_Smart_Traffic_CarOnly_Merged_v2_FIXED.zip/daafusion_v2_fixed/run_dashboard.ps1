# DAAFUSION Smart Traffic Platform launcher
if (Test-Path ".\venv\Scripts\Activate.ps1") { . .\venv\Scripts\Activate.ps1 }
python main.py
